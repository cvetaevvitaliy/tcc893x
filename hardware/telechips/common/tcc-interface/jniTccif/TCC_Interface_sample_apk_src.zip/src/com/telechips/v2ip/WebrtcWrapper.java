package com.telechips.v2ip;

import com.googlecode.javacpp.Loader;
import com.googlecode.javacpp.annotation.Name;
import com.googlecode.javacpp.annotation.Namespace;
import android.view.Surface;

//@Platform(include = "Camera_ctrl.h")
@Namespace("telechips")
@Name("WebrtcWrapper")

public class WebrtcWrapper
{
   static
   {
      /* this library */
      Loader.load();
   }
   
   public native static void start(Surface s1, Surface s2);
}
