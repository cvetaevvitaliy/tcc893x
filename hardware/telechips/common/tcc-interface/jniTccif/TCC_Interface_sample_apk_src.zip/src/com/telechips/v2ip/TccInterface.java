package com.telechips.v2ip;


import android.app.Activity;
import android.os.Bundle;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ToggleButton;

public class TccInterface extends Activity {
   static
   {
	   System.loadLibrary("tcc.video.call.direct.interface");
	   System.loadLibrary("tcc.video.call.interface");
	   System.loadLibrary("jniTccif");     
   }
  
   private int mNativeSurfaceTexture = 0;  // accessed by native methods
   
   public native int setCameraSurface(Surface surface, int width, int height, int bitrate, int framerate);
   public native int setVideoSurface(Surface surface);
   public native int startOperation(String packageName);
   public native int stopOperation();
   public native int changeFramerate(int fps);
   public native int changeBitrate(int bps);
   public native int requestIframe();
   public native void allocate();
   public native void deallocate();
   
   /** Called when the activity is first created. */
   @Override
   public void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.main2);

      /* I don't know what this does, but it's necessary, otherwise you get errors about being unable to create the Overlay */
//      ((SurfaceView) findViewById(R.id.sfvCamera)).getHolder().setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
//      ((SurfaceView) findViewById(R.id.sfvDecoded)).getHolder().setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
//      ((SurfaceView) findViewById(R.id.sfvDecoded1)).getHolder().setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

      ((Button) findViewById(R.id.btnQuit)).setOnClickListener(new View.OnClickListener()
      {
         public void onClick(View v)
         {
        	 deallocate();
            System.exit(0);
         }
      });

      ((Button) findViewById(R.id.btnChangeFPS)).setOnClickListener(new View.OnClickListener()
      {
         public void onClick(View v)
         {
        	 changeFramerate(0);
         }
      });
      
      ((Button) findViewById(R.id.btnChangeBPS)).setOnClickListener(new View.OnClickListener()
      {
         public void onClick(View v)
         {
        	 changeBitrate(0);
         }
      });
      
      ((Button) findViewById(R.id.btnRequestIFR)).setOnClickListener(new View.OnClickListener()
      {
         public void onClick(View v)
         {
        	 requestIframe();
         }
      });
      
      ((ToggleButton) findViewById(R.id.tglCamera)).setOnCheckedChangeListener(new OnCheckedChangeListener()
      {
         public void onCheckedChanged(CompoundButton arg0, boolean checked)
         {
            if(checked)
            {
            	//String packageName = ActivityThread.currentPackageName();
            	startOperation("com.telechips.v2ip");
            }
            else
            {              
              stopOperation();
            }
         }
      });

      ((SurfaceView) findViewById(R.id.sfvCamera)).getHolder().addCallback(new Callback()
      {

         public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
         {
        	 setCameraSurface(holder.getSurface(), 1280, 720, 3064, 20);
         }

         public void surfaceCreated(SurfaceHolder holder)
         {
         
         }

         public void surfaceDestroyed(SurfaceHolder holder)
         {
           ((ToggleButton) findViewById(R.id.tglCamera)).setChecked(false);
         }

      });

      ((SurfaceView) findViewById(R.id.sfvDecoded)).getHolder().addCallback(new Callback()
      {

         public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
         {
        	 setVideoSurface(holder.getSurface());
         }

         public void surfaceCreated(SurfaceHolder holder)
         {

         }

         public void surfaceDestroyed(SurfaceHolder holder)
         {
           
         }

      });
      
      ((SurfaceView) findViewById(R.id.sfvDecoded1)).getHolder().addCallback(new Callback()
      {

         public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
         {
        	 //setVideoSurface(holder.getSurface());
         }

         public void surfaceCreated(SurfaceHolder holder)
         {

         }

         public void surfaceDestroyed(SurfaceHolder holder)
         {
           
         }

      });
   }
}